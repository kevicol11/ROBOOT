package Strategy;

public interface RobotBehavior {
public int moveCommand();
}
