package Strategy;

public class NormalBehavior {
    public int moveCommand(){
return 0;
    }
    public String toString(){
        return"normal Behavior" + " if find another robot ignore it";
    }
}
